﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class CharController : MonoBehaviour
{
    float mspeed = 5.0f;
    public GameObject CoinCollected;
    

    private int coinCount;
    private int totalCoin;
    void Start()
    {
        totalCoin = GameObject.FindGameObjectsWithTag("Coin").Length;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.W))
        {
            transform.Translate(Vector3.forward * Time.deltaTime * mspeed);
            transform.rotation = Quaternion.Euler(0, 0, 0);
            

        }
        else if (Input.GetKey(KeyCode.S))
        {
            transform.Translate(Vector3.forward * Time.deltaTime * mspeed);
            transform.rotation = Quaternion.Euler(0, 180, 0);
            
        }
        else if (Input.GetKey(KeyCode.A))
        {
            transform.Translate(Vector3.forward * Time.deltaTime * mspeed);
            transform.rotation = Quaternion.Euler(0, -90, 0);
            
        }
        else if (Input.GetKey(KeyCode.D))
        {
            transform.Translate(Vector3.forward * Time.deltaTime * mspeed);
            transform.rotation = Quaternion.Euler(0, 90, 0);
            
        }
        if(coinCount==totalCoin)
        {
            //print("You Win!");
            SceneManager.LoadScene("surpasslimit");
        }
        if (transform.position.y<-5)
        {
            //print("You Lose!");
            SceneManager.LoadScene("limitsurpass");
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.tag=="Coin")
        {
            coinCount++;

            CoinCollected.GetComponent<Text>().text = "Coin Collected:" + coinCount;
            Destroy(other.gameObject);
        }
    }
}
